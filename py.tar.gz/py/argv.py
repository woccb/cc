#!/usr/bin/env python
from sys import argv
script,first,second,third = argv

print "The script is called: ",script
print "Your first variable is: ",first
print "Your second variavle is: ",second
print "Your third variavle is: ",third
