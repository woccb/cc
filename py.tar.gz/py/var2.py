#!/usr/bin/env python
my_name = 'Zed A. Shaw'
my_age = 35 # not a lie
my_weight = 174 # inches
my_height = 75 # lbs
my_eyes = 'blue'
my_teech = 'white'
my_hair = 'brown'

print "Let\'s talk about %s." % my_name
print "He\'s %d inches tall." % my_height
print "He\'s %d pounds heavy." % my_weight
print "Actually that\'s not too heavy."

print "He\'s got %s eyes and %s hair." %(my_eyes,my_hair)
print "His teeth are usually %s depending on the coffee." % my_teech
